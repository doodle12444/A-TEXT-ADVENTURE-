### Print a welcome message
print("WELCOME TO A TEXT ADVENTURE")
print("you are a random british guy from england also your on the run from every countries milatary")
print("you are in a forest and you have to get to a safe place")
print("you see a bank and a abondond mansion")
print("what place do you want to go to first type B for bank and type M for mansion?")

### Prompt user for a choice
placechoice = input("> ")

if(placechoice == "B"):
    print("you start walking to the bank and a cop sees you and you get arrested")
    print("you got the ending: arrested")

elif(placechoice == "M"):
    print("you go to the mansion and you see a gun and a knife")
    print("what do you want to take type G for gun and K for knife")

    gunorknife = input("> ")

    if(gunorknife == "K"):
        print("you take the knife and you see a cop and he arrests you ")
        print("you got the ending: better luck next time")

    if(gunorknife == "G"):
        print("you pick it up and you see a cop running to the mansion do you shoot him or surrender")
        print("type F to fire the gun and type S to surrender")
        fireornot = input("> ")

    if(fireornot == "F"):
        print("you fire the gun and the bullet misses the cop by a centimeter and you get shot instead by the cop")
        print("you got the ending: karma")

    if(fireornot == "S"):
        print("you surrender and the cop arrests you. the police escorts you to an airport to go to Italy because you committed most of your crimes there")
        print("you are now in the airplane and realize a plan to escape")
        print("you have 2 escape methods to choose from")
        print("one escape method is to jump out with a parachute and the other option is to try to hijack the plane which method do you choose")
        print("type J to jump out with a parachute and type H to hijack the plane")
        print("but that will be the end of the game so stay tuned for A TEXT ADVENTURE 2 PIZZA TIME")